// ==UserScript==
// @name	Mercator Studio for Google Meet
// @version	2.2.1
// @description	Change how you look on Google Meet.
// @author	Xing <dev@x-ing.space> (https://x-ing.space)
// @copyright	2020-2021, Xing (https://x-ing.space)
// @license	MIT License; https://x-ing.space/mercator/LICENSE
// @namespace	https://x-ing.space
// @homepageURL	https://x-ing.space/mercator
// @icon	https://x-ing.space/mercator/icon.png
// @match	https://meet.google.com/*
// @grant	none
// ==/UserScript==
(async function mercator_studio() {
	'use strict'

	// Create preview video
	const video = document.createElement('video')
	video.setAttribute('playsinline', '')
	video.setAttribute('autoplay', '')
	video.setAttribute('muted', '')

	// Create canvases
	const canvases = Object.fromEntries(['buffer', 'display'].map(name => {
		const element = document.createElement('canvas')
		const context = element.getContext('2d')
		return [name, {
			element,
			context
		}]
	}))

	let task = 0

	// Background Blur for Google Meet does this (hello@brownfoxlabs.com)

	function draw( width, height ) {
		const fill = [0, 0, width, height]
		const { context } = canvases.buffer
		
		context.clearRect(...fill)

		// Apply CSS filters & linear transformations
		if (video.srcObject) {
			// Draw video
			context.drawImage(video, ...fill)
		} else {
			// Draw preview stripes if video doesn't exist
			'18, 100%, 68%; -10,100%,80%; 5, 90%, 72%; 48, 100%, 75%; 36, 100%, 70%; 20, 90%, 70%'
			.split(';')
				.forEach((color, index) => {
					context.fillStyle = `hsl(${color})`
					context.fillRect(index * width / 6, 0, width / 6, height)
				})
		}

		// Text:
		const text = "Hello"
		if (text) {

			// Find out the font size that just fits

			const vw = 0.9 * width
			const vh = 0.9 * height
			const line_count = text.length

			context.font = `bold ${vw}px "Google Sans"`
			context.textAlign = 'center'
			context.textBaseline = 'middle'

			let char_metrics = context.measureText('0')
			let line_height = char_metrics.actualBoundingBoxAscent + char_metrics.actualBoundingBoxDescent
			let text_width = text.reduce(
				(max_width, current_line) => Math.max(
					max_width,
					context.measureText(current_line).width
				), 0 // Accumulator starts at 0
			)

			const font_size = Math.min(vw ** 2 / text_width, vh ** 2 / line_height / line_count)

			// Found the font size. Time to draw!

			context.font = `bold ${font_size}px ${display_fonts}`

			char_metrics = context.measureText('0')
			line_height = 1.5 * (char_metrics.actualBoundingBoxAscent + char_metrics.actualBoundingBoxDescent)

			context.lineWidth = font_size / 8
			context.strokeStyle = 'black'
			context.fillStyle = 'white'

			text.forEach((line, index) => {
				let position = [ ...center ]
				position[1] += line_height * (index - line_count / 2 + 0.5)
				context.strokeText(line, ...position)
				context.fillText(line, ...position)
			})
		}

		canvases.display.context.clearRect(...fill)
		canvases.display.context.drawImage(canvases.buffer.element, 0, 0)
	}

	class MeetMediaStream extends MediaStream {

		constructor(old_stream) {
			// Copy original stream settings
			super(old_stream)
			video.srcObject = old_stream

			const { width, height } = old_stream.getVideoTracks()[0].getSettings()
			Object.values(canvases).forEach(canvas => {
				canvas.element.width = width
				canvas.element.height = height
			})
			// Amp: for values that can range from 0 to +infinity, amp**value does the mapping.
			clearInterval(task)
			const fps = 30
			task = setInterval(draw, 1000/fps, width, height)
			const new_stream = canvases.display.element.captureStream(fps)
			new_stream.addEventListener('inactive', () => {
				old_stream.getTracks().forEach(track => track.stop())
				canvases.display.context.clearRect(...fill)
				video.srcObject = null
			})
			return new_stream
		}
	}

	MediaDevices.prototype.old_getUserMedia = MediaDevices.prototype.getUserMedia
	MediaDevices.prototype.getUserMedia = async constraints =>
		(constraints && constraints.video && !constraints.audio) ?
		new MeetMediaStream(await navigator.mediaDevices.old_getUserMedia(constraints)) :
		navigator.mediaDevices.old_getUserMedia(constraints)
})()
